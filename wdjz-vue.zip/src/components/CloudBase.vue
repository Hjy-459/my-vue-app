<template>

</template>

<script>
export default {
  name: "CloudBase"
}
</script>

<style scoped>

</style>